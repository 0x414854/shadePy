class Colors:
    BLACK = '\33[30m'
    RED = '\33[31m'
    GREEN = '\33[32m'
    YELLOW = '\33[33m'
    BLUE = '\33[34m'
    MAGENTA = '\33[35m'
    CYAN = '\33[36m'
    WHITE = '\33[37m'
    GREY = '\33[2m'
    BRIGHTGREY = '\33[90m'
    BRIGHTRED = '\33[91m'
    BRIGHTGREEN = '\33[92m'
    BRIGHTYELLOW = '\33[93m'
    BRIGHTBLUE = '\33[94m'
    BRIGHTMAGENTA = '\33[95m'
    BRIGHTCYAN = '\33[96m'
    RESET = '\033[0m'

class Back:
    BLACK = "\33[40m"
    RED = "\33[41m"
    GREEN = "\33[42m"
    YELLOW = "\33[43m"
    BLUE = "\33[44m"
    MAGENTA = "\33[45m"
    CYAN = "\33[46m"
    BRIGHTGREY = '\33[100m'
    BRIGHTRED = '\33[101m'
    BRIGHTGREEN = '\33[102m'
    BRIGHTYELLOW = '\33[103m'
    BRIGHTBLUE = '\33[104m'
    BRIGHTMAGENTA = '\33[105m'
    BRIGHTCYAN = '\33[106m'
